package br.com.alura;

import java.util.Collection;
import java.util.HashSet;

public class QualColecaoUsar {
	
	public static void main(String[] args) {
		
		Collection<Aluno> alunos = new HashSet<>();
		
	}
}
