public class Conta {

    void deposita() {}

}